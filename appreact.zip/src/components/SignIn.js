import React, { Component } from 'react';

class SignIn extends Component {

	constructor(props){
		super(props);
		//this.props.history.push('/login');
	}

  render() {
    return (
      <div>
        <h1>Sign In Page</h1>
      </div>
    );
  }
}

export default SignIn;
