import React, { Component } from 'react';

class SignUp extends Component {

	constructor(props){
		super(props);
		//this.props.history.push('/login');
	}

  render() {
    return (
      <div>
        <h1>Sign Up Page</h1>
      </div>
    );
  }
}

export default SignUp;
